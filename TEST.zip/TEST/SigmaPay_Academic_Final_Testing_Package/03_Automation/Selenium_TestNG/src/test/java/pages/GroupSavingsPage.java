
package pages;
import org.openqa.selenium.*;
import org.openqa.selenium.support.*;

public class GroupSavingsPage {
  @FindBy(name="groupName") WebElement name;
  @FindBy(xpath="//button[contains(text(),'Create Group')]") WebElement createBtn;
  @FindBy(xpath="//p") WebElement message;

  public GroupSavingsPage(WebDriver driver) {
    PageFactory.initElements(driver, this);
  }

  public void createGroup(String n) {
    name.sendKeys(n);
    createBtn.click();
  }

  public boolean success() {
    return message.isDisplayed();
  }
}
