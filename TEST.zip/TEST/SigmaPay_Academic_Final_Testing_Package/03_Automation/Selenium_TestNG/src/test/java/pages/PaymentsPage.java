
package pages;
import org.openqa.selenium.*;
import org.openqa.selenium.support.*;

public class PaymentsPage {
  @FindBy(name="amount") WebElement amount;
  @FindBy(xpath="//button[contains(text(),'Process')]") WebElement processBtn;
  @FindBy(xpath="//p") WebElement message;

  public PaymentsPage(WebDriver driver) {
    PageFactory.initElements(driver, this);
  }

  public void pay(String a) {
    amount.sendKeys(a);
    processBtn.click();
  }

  public boolean success() {
    return message.isDisplayed();
  }
}
