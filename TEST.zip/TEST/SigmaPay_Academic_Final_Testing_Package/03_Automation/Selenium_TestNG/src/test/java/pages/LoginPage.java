
package pages;
import org.openqa.selenium.*;
import org.openqa.selenium.support.*;

public class LoginPage {
  WebDriver driver;
  @FindBy(id="email") WebElement email;
  @FindBy(id="password") WebElement password;
  @FindBy(xpath="//button[contains(text(),'Login')]") WebElement loginBtn;
  @FindBy(xpath="//p") WebElement message;

  public LoginPage(WebDriver driver) {
    this.driver = driver;
    PageFactory.initElements(driver, this);
  }

  public void login(String e, String p) {
    email.clear(); email.sendKeys(e);
    password.clear(); password.sendKeys(p);
    loginBtn.click();
  }

  public boolean hasMessage() {
    return message.isDisplayed();
  }
}
