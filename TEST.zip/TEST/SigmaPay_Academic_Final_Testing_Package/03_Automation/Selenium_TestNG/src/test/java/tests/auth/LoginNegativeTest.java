
package tests.auth;
import base.BaseTest;
import pages.LoginPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class LoginNegativeTest extends BaseTest {
  @Test
  public void invalidLogin() {
    driver.get("http://localhost:3000/login");
    LoginPage lp = new LoginPage(driver);
    lp.login("test@sigma.com","wrong");
    Assert.assertTrue(lp.hasMessage());
  }
}
