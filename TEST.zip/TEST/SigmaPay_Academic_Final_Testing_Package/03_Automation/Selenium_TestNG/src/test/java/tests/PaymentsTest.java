package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import base.BaseTest;
import pages.LoginPage;
import pages.PaymentsPage;

public class PaymentsTest extends BaseTest {

    @Test
    public void processPaymentFlow() {
        // Login
        driver.get("http://localhost:3000/login");
        LoginPage lp = new LoginPage(driver);
        lp.login("test@sigma.com", "Password123!");

        // Go to payments page and make payment
        driver.get("http://localhost:3000/payments");
        PaymentsPage pp = new PaymentsPage(driver);
        pp.pay("15.75");
        Assert.assertTrue(pp.success(), "Payment should show success message");
    }
}
