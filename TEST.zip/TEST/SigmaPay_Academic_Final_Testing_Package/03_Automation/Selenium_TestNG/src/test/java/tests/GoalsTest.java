package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import base.BaseTest;
import pages.GoalsPage;
import pages.LoginPage;

public class GoalsTest extends BaseTest {

    @Test
    public void createGoalFlow() {
        // Login
        driver.get("http://localhost:3000/login");
        LoginPage lp = new LoginPage(driver);
        lp.login("test@sigma.com", "Password123!");

        // Go to goals page and create goal
        driver.get("http://localhost:3000/goals");
        GoalsPage gp = new GoalsPage(driver);
        gp.createGoal("500", "2026-06-01");
        Assert.assertTrue(gp.success(), "Goal creation should show success message");
    }
}
