
package pages;
import org.openqa.selenium.*;
import org.openqa.selenium.support.*;

public class DashboardPage {
  @FindBy(xpath="//h2[contains(text(),'Dashboard')]")
  WebElement header;

  public DashboardPage(WebDriver driver) {
    PageFactory.initElements(driver, this);
  }

  public boolean isLoaded() {
    return header.isDisplayed();
  }
}
