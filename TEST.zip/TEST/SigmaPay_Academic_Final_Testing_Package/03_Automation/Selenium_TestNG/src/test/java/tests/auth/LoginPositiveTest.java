
package tests.auth;
import base.BaseTest;
import pages.*;
import org.testng.Assert;
import org.testng.annotations.Test;

public class LoginPositiveTest extends BaseTest {
  @Test
  public void validLogin() {
    driver.get("http://localhost:3000/login");
    LoginPage lp = new LoginPage(driver);
    DashboardPage dp = new DashboardPage(driver);
    lp.login("test@sigma.com","Password123!");
    Assert.assertTrue(dp.isLoaded());
  }
}
