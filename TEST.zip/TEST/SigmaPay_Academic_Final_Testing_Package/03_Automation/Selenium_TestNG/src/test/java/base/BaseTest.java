
package base;
import core.DriverFactory;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;

public class BaseTest {
  protected WebDriver driver;

  @BeforeMethod
  public void setup() {
    driver = DriverFactory.getDriver();
    driver.manage().window().maximize();
    driver.get("http://localhost:3000");
  }

  @AfterMethod
  public void teardown() {
    if (driver != null) driver.quit();
  }
}
