
package pages;
import org.openqa.selenium.*;
import org.openqa.selenium.support.*;

public class ReportsPage {
  @FindBy(xpath="//button[contains(text(),'Generate')]") WebElement generate;
  @FindBy(xpath="//div") WebElement report;

  public ReportsPage(WebDriver driver) {
    PageFactory.initElements(driver, this);
  }

  public void generateReport() {
    generate.click();
  }

  public boolean visible() {
    return report.isDisplayed();
  }
}
