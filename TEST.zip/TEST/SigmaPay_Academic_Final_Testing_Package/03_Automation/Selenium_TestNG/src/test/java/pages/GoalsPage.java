
package pages;
import org.openqa.selenium.*;
import org.openqa.selenium.support.*;

public class GoalsPage {
  @FindBy(name="amount") WebElement amount;
  @FindBy(name="deadline") WebElement deadline;
  @FindBy(xpath="//button[contains(text(),'Create')]") WebElement createBtn;
  @FindBy(xpath="//p") WebElement message;

  public GoalsPage(WebDriver driver) {
    PageFactory.initElements(driver, this);
  }

  public void createGoal(String a, String d) {
    amount.sendKeys(a);
    deadline.sendKeys(d);
    createBtn.click();
  }

  public boolean success() {
    return message.isDisplayed();
  }
}
